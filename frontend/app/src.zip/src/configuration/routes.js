const API_BASE_URL = "http://localhost:8080";

const apiRoutes = {
  listFiles: (path) => `${API_BASE_URL}/file/list?path=${encodeURIComponent(path)}`,
  downloadFile: (path) => `${API_BASE_URL}/file/download?path=${encodeURIComponent(path)}`,
  saveFile: `${API_BASE_URL}/file/save`,
  deleteFile: `${API_BASE_URL}/file/delete`,
  moveFile: `${API_BASE_URL}/file/move`,
};

export default apiRoutes;
