import React from "react";

const OptionsButton = ({ isFolder, onEdit, onDelete }) => {
  return (
    <div className="btn-group">
      {!isFolder && (
        <button className="btn btn-sm btn-outline-primary" onClick={onEdit}>
          Editar
        </button>
      )}
      <button className="btn btn-sm btn-outline-danger" onClick={onDelete}>
        Deletar
      </button>
    </div>
  );
};

export default OptionsButton;
