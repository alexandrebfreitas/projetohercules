import React from "react";
import { Droppable } from "react-beautiful-dnd";
import Card from "./Card";

const Columns = ({ study, studyIndex, handleEdit, handleDelete }) => {
  return (
    <Droppable droppableId={`${studyIndex}`}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.droppableProps}
          className="bg-light rounded shadow-sm p-3"
          style={{ minWidth: "300px", maxWidth: "300px", overflowY: "auto" }}
        >
          <h5 className="text-center">{study.name}</h5>
          {study.items.map((item, itemIndex) => (
            <Card
              key={item.path}
              item={item}
              index={itemIndex}
              handleEdit={handleEdit}
              handleDelete={() => handleDelete(item.path, studyIndex)}
            />
          ))}
          {provided.placeholder}
        </div>
      )}
    </Droppable>
  );
};

export default Columns;
