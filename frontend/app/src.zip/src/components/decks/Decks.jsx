import React, { useState, useEffect } from "react";
import { DragDropContext } from "react-beautiful-dnd";
import axios from "axios";
import apiRoutes from "../configuration/routes";
import Columns from "../components/decks/column";
import Editor from "../components/editor/Editor";

const Decks = () => {
  const [studies, setStudies] = useState([]);
  const [editingFile, setEditingFile] = useState(null);

  useEffect(() => {
    loadStudies();
  }, []);

  const loadStudies = async () => {
    try {
      const response = await axios.get(apiRoutes.listFiles("estudos"));
      const studiesData = response.data
        .filter((item) => item.endsWith("/"))
        .map((study) => ({
          name: study.replace(/\/$/, ""),
          path: `estudos/${study}`,
          items: [],
          expanded: false,
        }));

      setStudies(studiesData);

      for (const study of studiesData) {
        await loadStudyItems(study);
      }
    } catch (error) {
      console.error("Erro ao carregar os estudos:", error);
    }
  };

  const loadStudyItems = async (study) => {
    try {
      const response = await axios.get(apiRoutes.listFiles(study.path));
      setStudies((prevStudies) =>
        prevStudies.map((s) =>
          s.name === study.name
            ? {
                ...s,
                items: response.data.map((item) => ({
                  name: item.replace(/\/$/, ""),
                  isFolder: item.endsWith("/"),
                  path: `${study.path}/${item}`,
                  items: [],
                  expanded: false,
                })),
              }
            : s
        )
      );
    } catch (error) {
      console.error(`Erro ao carregar itens para o estudo ${study.name}:`, error);
    }
  };

  const handleMove = async (movedItem, sourcePath, destinationPath) => {
    try {
      await axios.post(apiRoutes.moveFile, {
        fileName: movedItem.name,
        from: sourcePath,
        to: destinationPath,
      });
    } catch (error) {
      console.error(`Erro ao mover o item ${movedItem.name}:`, error);
    }
  };

  const handleDelete = async (filePath, studyIndex) => {
    try {
      await axios.delete(apiRoutes.deleteFile, { params: { path: filePath } });
      setStudies((prevStudies) =>
        prevStudies.map((study, index) =>
          index === studyIndex
            ? { ...study, items: study.items.filter((item) => item.path !== filePath) }
            : study
        )
      );
    } catch (error) {
      console.error(`Erro ao deletar o arquivo ${filePath}:`, error);
    }
  };

  const handleEdit = async (filePath) => {
    setEditingFile(filePath);
  };

  const onDragEnd = async (result) => {
    if (!result.destination) return;

    const { source, destination } = result;
    const sourceStudy = studies[source.droppableId];
    const destinationStudy = studies[destination.droppableId];

    const sourceItems = [...sourceStudy.items];
    const destinationItems = [...destinationStudy.items];
    const [movedItem] = sourceItems.splice(source.index, 1);
    destinationItems.splice(destination.index, 0, movedItem);

    setStudies((prevStudies) =>
      prevStudies.map((study, idx) => {
        if (idx === parseInt(source.droppableId)) {
          return { ...study, items: sourceItems };
        } else if (idx === parseInt(destination.droppableId)) {
          return { ...study, items: destinationItems };
        }
        return study;
      })
    );

    await handleMove(movedItem, sourceStudy.path, destinationStudy.path);
  };

  return (
    <div className="container-fluid">
      <h1 className="text-center my-4">Estudos</h1>
      <DragDropContext onDragEnd={onDragEnd}>
        <div className="d-flex flex-row gap-3 overflow-auto">
          {studies.map((study, index) => (
            <Columns
              key={index}
              study={study}
              studyIndex={index}
              handleEdit={handleEdit}
              handleDelete={handleDelete}
            />
          ))}
        </div>
      </DragDropContext>
      {editingFile && (
        <Editor
          filePath={editingFile}
          onClose={() => setEditingFile(null)}
        />
      )}
    </div>
  );
};

export default Decks;
