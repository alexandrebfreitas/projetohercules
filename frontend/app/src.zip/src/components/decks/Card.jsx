import React from "react";
import { Draggable } from "react-beautiful-dnd";
import OptionsButton from "./OptionsButton";

const Card = ({ item, index, handleEdit, handleDelete }) => {
  return (
    <Draggable draggableId={item.path} index={index}>
      {(provided) => (
        <div
          ref={provided.innerRef}
          {...provided.draggableProps}
          {...provided.dragHandleProps}
          className="border mb-2 p-2 rounded bg-white d-flex justify-content-between align-items-center"
        >
          <span>{item.name}</span>
          <OptionsButton
            isFolder={item.isFolder}
            onEdit={() => handleEdit(item.path)}
            onDelete={handleDelete}
          />
        </div>
      )}
    </Draggable>
  );
};

export default Card;
